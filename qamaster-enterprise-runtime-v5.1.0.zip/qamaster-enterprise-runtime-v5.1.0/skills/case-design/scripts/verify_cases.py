#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
verify_cases.py — 测试用例 .md 内容级校验 + 覆盖统计（Tier B 降本脚本）

用途：TestCases_<需求标识>.md 落盘后，由 skill 经 Bash 在第13阶段回读环节
与 verify_md.py 串联调用（见 references/output_write.md）。
verify_md.py 只校验“结构”（行数/表头/末行/列宽）；本脚本进一步校验
“内容层 + 覆盖广度 + 追溯性”，把 references/selfcheck.md 中【可机器判定】的
检查项客观化，并在覆盖广度不足时给出客观数据，供模型判定 selfcheck 自修项是否通过。

【设计不变】本脚本不新增门禁、不改变 selfcheck 的 15 项检查（检查15 业务行为来源追溯为新增软性项）、
不改变自修/阻断
决策、不改变“回读不一致→内存修正→重新整体 Write”机制（见 output_write.md）。
仅把“可机器判定的检查”从模型主观自证迁移到脚本客观判定，判定标准与
selfcheck.md / modeling.md / quality_rules.md / risk.md / coverage.md 完全一致。

校验项（对应 selfcheck 检查项，标准见各 references）：
  检查11 字段规范：测试类型/测试维度在枚举内、用例名称四段、4 固定列取值、用例等级 P0-P3
  检查5  ID 连续：用例ID 全局唯一不跳号（按 功能缩写分组连续）
  检查4  断言可观测：Then 含可观测关键词、不含模糊词（软判定，列疑似条数）
  检查9  存储合规：无杜撰表名/字段名/Redis Key/Topic/Index/Bucket（软判定，列疑似条数）
  检查9增强 存储schema交叉：若 .md 含'技术实现摘要'section，断言存储名须在清单内（软判定，无清单则跳过退回检查9正则）
  检查6  重复用例：关联规则+断言+维度+类型+等级五者全同（软判定，列疑似条数）
  检查7  过度设计：Then 无业务锚点（接口码/状态/数据/日志/MQ/缓存/业务数值/业务反馈）→ 疑似（软判定，兼容性/可靠性豁免，服务"不冗余不机械"）
  检查13 断言完整性：状态变更类用例(When含状态变更动词) Then 须含数据/状态副作用（软判定，防"测试通过却漏 bug"）
  检查15 业务行为来源追溯(#5)：用例 Given/When/Then 断言的业务行为须有来源三选一（需求文档 token / R·TP·API 引用 / 假设标记），三者皆无→疑似脑补（软判定）
  #6 反向接口追溯：变更影响清单每个变更接口须三类覆盖(契约 presence+type+出参 / 规则 R / 场景 SC)；无清单则跳过（软判定）
  关联需求ID追溯：笼统占位/全员相同→需求条目级追溯失效（软判定，对应 modeling.md 20.2）

覆盖统计（给 selfcheck 检查2/3/8 客观数据，不替代模型判定，只供证据）：
  - 标签维度：测试类型种类数、测试维度种类数、风险等级分布
  - 关键词维度（对测试类型标签错标鲁棒，扫描用例全文）：并发/幂等/安全/上下游/时间组合/界面查询/界面列表（UI 非每需求必有，按需，仅统计不强告警；需求涉列表/查询且=0 由 selfcheck 检查14 复核按需补齐）
  - 状态机流转：合法/非法/回滚/终态（非法流转为状态机核心，0 则提示）
  - 边界深度：边界用例是否覆盖 最小/最大/临界/边界内 四值（边界内=min+1/max-1 刚好满足约束应通过）
  - 异常子类：异常用例覆盖的子类数（输入/数据/状态/权限/服务/网络/缓存/MQ）
  - 规则追溯：解析“规则建模”section 的规则类别，校验每类是否被用例覆盖
  - 风险追溯：解析“风险清单”section，校验每 P0/P1 风险是否被用例覆盖
  - 风险来源：解析第5列“风险来源”，对技术隐含@开发/业务领域@业务/缺陷反哺来源的 P0/P1 提示需台账角色确认
  - 测试点追溯：解析“测试点清单”section，校验每测试点是否被用例覆盖
  - #4 反向需求追溯：解析需求文档条目（第2参数），列出未被用例引用的需求条目
  - #5 反向行为来源追溯（检查15）：用例 Given/When/Then 断言的业务行为须有来源三选一（需求文档 token / R·TP·API 引用 / 假设标记）；规则建模 section 规则项无来源标记->疑似脑补规则
  （风险/测试点清单为强制沉淀 section，缺失则 ⚠ 提示补齐；见 references/output_write.md 追溯性 section）

退出码：0=内容校验全过（覆盖统计与软性提示仍输出，仅供模型参考）；
        1=存在硬性内容违规（枚举越界/四段缺失/固定列错值/等级越界/ID跳号重复）
软判定项（断言/存储/存储schema/重复/断言完整性）与覆盖统计/追溯违规只列疑似条数与位置，
不强制 exit=1，由模型结合 selfcheck 决策（自修项：内存修正后重新整体 Write；阻断项：回前置阶段）。

用法：python verify_cases.py <TC文件.md> [需求文档.md]
      第2参数（可选）：需求文档，用于 #4 反向需求追溯；不传则该检查跳过。
      python verify_cases.py --dump-rules  查看规则契约

本脚本是 skill 自带可复用资产，不删除（见 references/output_write.md ch30）。

规则契约单一事实源：config/validation_rules.json（本脚本与 verify_md.py 共同加载）。
agent 需要规则契约（枚举/正则/关键词/section 格式）时运行 `python verify_cases.py --dump-rules`，
无需读本脚本源码；config/domain_config.json 提供可选领域覆盖（同名字段替换）。
"""
import sys
import os
import re
import json
import hashlib

# Windows 控制台默认 cp936，强制 stdout 输出 UTF-8，避免中文乱码
try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

# 15 列顺序（0-based）：
# 0用例ID 1关联需求ID 2关联规则 3测试类型 4测试维度 5所属模块 6用例名称
# 7Given 8When 9Then 10编辑模式 11标签 12责任人 13用例等级 14用例状态
IDX_ID, IDX_REQ, IDX_RULE, IDX_TYPE, IDX_DIM, IDX_MOD, IDX_NAME = 0, 1, 2, 3, 4, 5, 6
IDX_GIVEN, IDX_WHEN, IDX_THEN = 7, 8, 9
IDX_EDITMODE, IDX_TAG, IDX_OWNER, IDX_LEVEL, IDX_STATUS = 10, 11, 12, 13, 14

# ===== 校验规则单一事实源（config/validation_rules.json）=====
# 所有规则数据（枚举/正则/关键词/section 格式）集中于 validation_rules.json，
# 本脚本与 verify_md.py 共同加载该清单；domain_config.json 在此基础上按领域覆盖。
# agent 需要规则契约时运行 `python verify_cases.py --dump-rules`，无需读本脚本源码。
# 各常量来源（行内注释对应 references）：枚举(modeling.md 20.4/20.6)、断言可观测(quality_rules.md 11)、
# 存储合规(quality_rules.md ch12)、关键词维度(coverage.md 8.x)、状态机(example.md 范例2)、
# 边界(quality_rules.md 11.4)、异常子类(coverage.md 8.2)、需求ID追溯(modeling.md 20.2)。


def _rules_path():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "config", "validation_rules.json")


def _load_validation_rules():
    """加载校验规则清单（单一事实源）。缺失/异常则返回 None，由调用方决定退出。"""
    p = _rules_path()
    if not os.path.exists(p):
        print("校验规则清单缺失: %s（skill 资产，须与 scripts 同 bundle）" % p)
        return None
    try:
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print("校验规则清单读取失败: %s -> %s" % (p, e))
        return None


_RULES = _load_validation_rules()
if _RULES is None:
    sys.exit(1)

# 枚举与固定值（modeling.md 20.4 / 20.6 / 20.7-20.10）
VALID_TYPES = set(_RULES["valid_types"])
VALID_DIMS = set(_RULES["valid_dims"])
VALID_LEVELS = set(_RULES["valid_levels"])
_fc = _RULES["fixed_columns"]
FIX_EDITMODE, FIX_TAG, FIX_OWNER, FIX_STATUS = _fc["edit_mode"], _fc["tag"], _fc["owner"], _fc["status"]

# 断言可观测 / 模糊词（quality_rules.md 11.1 / 11.2）
VAGUE_WORDS = list(_RULES["vague_words"])
OBSERVABLE_PATTERNS = list(_RULES["observable_patterns"])

# 存储合规（quality_rules.md ch12）
STORAGE_PATTERNS = [(p["pattern"], p["desc"]) for p in _RULES["storage_patterns"]]
STORAGE_NATURAL = list(_RULES["storage_natural"])

# 用例名称四段（modeling.md 20.5）
NAME_SEGMENTS = _RULES["name_segments"]

# 关键词维度（coverage.md 8.x）；高价值维度 0 则警告：并发/幂等/安全/上下游
KEYWORD_DIMS = {k: list(v) for k, v in _RULES["keyword_dims"].items()}
HIGH_VALUE_DIMS = set(_RULES["high_value_dims"])

# 状态机流转锚点（example.md 范例2）
FLOW_LEGAL = list(_RULES["flow_legal"])
FLOW_ILLEGAL = list(_RULES["flow_illegal"])
FLOW_ROLLBACK = list(_RULES["flow_rollback"])
FLOW_TERMINAL = list(_RULES["flow_terminal"])

# 边界深度（quality_rules.md 11.4 / modeling.md 边界类）
# 4 值模型：最小 / 最大 / 临界(=边界点) / 边界内(min+1/max-1, 刚好满足约束应通过)
BOUNDARY_KEYWORDS = list(_RULES["boundary_keywords"])
BOUNDARY_MIN_KW = list(_RULES["boundary_min_kw"])
BOUNDARY_MAX_KW = list(_RULES["boundary_max_kw"])
BOUNDARY_CRITICAL_KW = list(_RULES["boundary_critical_kw"])
BOUNDARY_INSIDE_KW = list(_RULES["boundary_inside_kw"])

# 异常子类（coverage.md 8.2）
EXCEPTION_SUBTYPES = {k: list(v) for k, v in _RULES["exception_subtypes"].items()}

# 过度设计·业务价值信号（quality_rules.md 0.1 / 11.2）；豁免类型：兼容性/可靠性
BUSINESS_ANCHORS = list(_RULES["business_anchors"])
OVERDESIGN_EXEMPT_TYPES = set(_RULES["overdesign_exempt_types"])

# 关联需求ID 笼统占位模式（modeling.md 20.2）；命中且全员相同 → 需求条目级追溯失效
VAGUE_REQ_PATTERNS = list(_RULES["vague_req_patterns"])

# ===== 领域配置加载（方向3·领域适配）=====
# 优先读取 scripts/../config/domain_config.json，缺失或异常用上面内置默认。
# 用户可按领域扩展 business_anchors/keyword_dims/exception_subtypes/overdesign_exempt_types。


def _load_domain_config():
    cfg_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "config", "domain_config.json")
    if not os.path.exists(cfg_path):
        return {}
    try:
        with open(cfg_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


_DOMAIN_CFG = _load_domain_config()
if "business_anchors" in _DOMAIN_CFG:
    BUSINESS_ANCHORS = _DOMAIN_CFG["business_anchors"]
if "keyword_dims" in _DOMAIN_CFG:
    # dict 字段做 key 级合并（领域扩展语义）：保留 validation_rules 独有 key
    # （如 0.5.0 新增的界面查询/界面列表），domain_config 同名 key 覆盖 value、
    # 领域新增 key 加入。整体替换会丢掉内置 key，与 _usage"新增字段不覆盖内置"矛盾。
    _merged_kw = dict(KEYWORD_DIMS)
    _merged_kw.update({k: list(v) for k, v in _DOMAIN_CFG["keyword_dims"].items()})
    KEYWORD_DIMS = _merged_kw
if "exception_subtypes" in _DOMAIN_CFG:
    # dict 字段同上：key 级合并，保留内置子类，domain_config 同名/新增子类覆盖或加入
    _merged_exc = dict(EXCEPTION_SUBTYPES)
    _merged_exc.update({k: list(v) for k, v in _DOMAIN_CFG["exception_subtypes"].items()})
    EXCEPTION_SUBTYPES = _merged_exc
if "overdesign_exempt_types" in _DOMAIN_CFG:
    OVERDESIGN_EXEMPT_TYPES = set(_DOMAIN_CFG["overdesign_exempt_types"])


def split_row(line):
    s = line.strip()
    if not s.startswith("|"):
        return None
    s = s[1:]
    if s.endswith("|"):
        s = s[:-1]
    return [c.strip() for c in s.split("|")]


def is_separator(cells):
    if not cells:
        return False
    for c in cells:
        if not set(c) <= set("-: "):
            return False
    return True


def parse_table_from_lines(lines):
    """解析已读入的 .md 行列表中的用例表，返回 (header_cells, data_rows, full_lines)。
    与文件读无关——供内存内 gate 调用（Phase 8 出口 gate 在写盘前对 Write 的 content
    即将落盘文本跑全量校验，零临时文件）。"""
    header_idx = None
    header_cells = None
    for i, ln in enumerate(lines):
        cells = split_row(ln)
        if cells and "用例ID" in cells[0]:
            header_idx = i
            header_cells = cells
            break
    if header_idx is None:
        return None, "未找到表头行（含'用例ID'的表格行）"

    data_rows = []
    for ln in lines[header_idx + 1:]:
        cells = split_row(ln)
        if cells is None:
            if data_rows:
                break
            else:
                continue
        if is_separator(cells) or len(cells) == 0:
            continue
        data_rows.append(cells)
    return (header_cells, data_rows, lines), None


def parse_table(path):
    """解析 .md 中的用例表，返回 (header_cells, data_rows, full_lines)。
    文件入口（Phase 13 回读用）；内部读文件后委托 parse_table_from_lines。"""
    if not os.path.exists(path):
        return None, "文件不存在: %s" % path
    try:
        with open(path, "r", encoding="utf-8") as f:
            lines = f.readlines()
    except Exception as e:
        return None, "读取失败: %s" % e
    return parse_table_from_lines(lines)


def count_segments(name):
    return len(re.findall(r"【[^】]*】", name))


def extract_func_abbr(case_id):
    if not case_id:
        return None, None
    parts = case_id.split("_")
    if len(parts) < 2:
        return None, None
    seq = parts[-1]
    func = parts[-2] if len(parts) >= 3 else None
    return func, seq


def seq_num(seq):
    try:
        return int(seq)
    except Exception:
        return None


def check_ids(data_rows):
    violations = []
    seen = {}
    groups = {}
    for i, r in enumerate(data_rows, 1):
        cid = r[IDX_ID] if len(r) > IDX_ID else ""
        if cid in seen:
            violations.append("行%d: 用例ID重复 %s（首次出现于行%d）" % (i, cid, seen[cid]))
        else:
            seen[cid] = i
        func, seq = extract_func_abbr(cid)
        if func is None:
            continue
        n = seq_num(seq)
        if n is None:
            continue
        groups.setdefault(func, []).append((n, i, cid))
    for func, items in groups.items():
        nums = sorted(n for n, _, _ in items)
        if not nums:
            continue
        expected = list(range(nums[0], nums[-1] + 1))
        missing = set(expected) - set(nums)
        if missing:
            violations.append("功能[%s]序号跳号，缺失: %s" % (func, ",".join(str(x) for x in sorted(missing))))
    return violations


def check_fields(data_rows):
    violations = []
    for i, r in enumerate(data_rows, 1):
        if len(r) <= IDX_STATUS:
            violations.append("行%d: 列数不足15，无法校验字段" % i)
            continue
        ctype, cdim, cname = r[IDX_TYPE], r[IDX_DIM], r[IDX_NAME]
        cedit, ctag, cowner, clevel, cstatus = r[IDX_EDITMODE], r[IDX_TAG], r[IDX_OWNER], r[IDX_LEVEL], r[IDX_STATUS]
        if ctype not in VALID_TYPES:
            violations.append("行%d: 测试类型越界『%s』（允许：%s）" % (i, ctype, "/".join(sorted(VALID_TYPES))))
        if cdim not in VALID_DIMS:
            violations.append("行%d: 测试维度越界『%s』（允许：%s）" % (i, cdim, "/".join(sorted(VALID_DIMS))))
        if count_segments(cname) < NAME_SEGMENTS:
            violations.append("行%d: 用例名称段数不足（%d段<%d）『%s』" % (i, count_segments(cname), NAME_SEGMENTS, cname))
        if cedit != FIX_EDITMODE:
            violations.append("行%d: 编辑模式固定值应为%s，实际『%s』" % (i, FIX_EDITMODE, cedit))
        if ctag != FIX_TAG:
            violations.append("行%d: 标签固定值应为%s，实际『%s』" % (i, FIX_TAG, ctag))
        if cowner != FIX_OWNER:
            violations.append("行%d: 责任人固定值应为%s，实际『%s』" % (i, FIX_OWNER, cowner))
        if cstatus != FIX_STATUS:
            violations.append("行%d: 用例状态固定值应为%s，实际『%s』" % (i, FIX_STATUS, cstatus))
        if clevel not in VALID_LEVELS:
            violations.append("行%d: 用例等级越界『%s』（允许P0-P3）" % (i, clevel))
    return violations


def check_assertions(data_rows):
    suspects = []
    for i, r in enumerate(data_rows, 1):
        then = r[IDX_THEN] if len(r) > IDX_THEN else ""
        if not then.strip():
            suspects.append("行%d: Then 为空" % i)
            continue
        if any(re.search(p, then) for p in OBSERVABLE_PATTERNS):
            continue
        vague_hit = [w for w in VAGUE_WORDS if w in then]
        if vague_hit:
            suspects.append("行%d: Then 疑似模糊断言（含%s且无可观测锚点）" % (i, "/".join(vague_hit)))
        else:
            suspects.append("行%d: Then 未识别到可观测锚点（请人工复核）" % i)
    return len(suspects), suspects


def check_storage(data_rows):
    suspects = []
    for i, r in enumerate(data_rows, 1):
        text = " ".join(r[IDX_GIVEN:IDX_THEN + 1]) if len(r) > IDX_THEN else ""
        hits = [desc for pat, desc in STORAGE_PATTERNS if re.search(pat, text, flags=re.IGNORECASE)]
        if hits:
            natural = [n for n in STORAGE_NATURAL if n in text]
            tag = "（含自然语言描述，请复核）" if natural else ""
            suspects.append("行%d: %s%s" % (i, ";".join(hits), tag))
    return len(suspects), suspects


def check_duplicates(data_rows):
    """检查6：重复用例（软判定）。按 dedup_coverage.md 维度/方法多样性保护：
    关联规则+断言+测试维度+测试类型+用例等级（P0-P3 代理风险）五者全同才报疑似重复
   （用例表无独立"风险"列，以用例等级代理；保护宽度，防过度合并）。"""
    seen = {}
    suspects = []
    for i, r in enumerate(data_rows, 1):
        rule = r[IDX_RULE] if len(r) > IDX_RULE else ""
        then = r[IDX_THEN] if len(r) > IDX_THEN else ""
        cdim = r[IDX_DIM] if len(r) > IDX_DIM else ""
        ctype = r[IDX_TYPE] if len(r) > IDX_TYPE else ""
        clevel = r[IDX_LEVEL] if len(r) > IDX_LEVEL else ""
        key = (rule.strip(), then.strip(), cdim.strip(), ctype.strip(), clevel.strip())
        if key in seen:
            suspects.append("行%d: 与行%d 规则+断言+维度+类型+等级全同（疑似重复）" % (i, seen[key]))
        else:
            seen[key] = i
    return len(suspects), suspects


def check_overdesign(data_rows):
    """检查7：过度设计（软判定·业务价值信号）。判定 Then 有无业务锚点
    （接口码/状态/数据/日志/MQ/缓存/业务数值/业务反馈）；无业务锚点 → 疑似过度设计
   （对应 quality_rules.md 0.1：聚焦业务/数据/状态/权限/风险，禁止无业务价值UI/框架测试）。
    兼容性/可靠性测试类型豁免（纯 UI/性能断言合理）。比句式匹配更准：不误伤含'能否'但
    有业务断言的用例（如'支付失败能否显示错误提示'含错误码），不漏检纯元素存在类。"""
    suspects = []
    for i, r in enumerate(data_rows, 1):
        if len(r) <= IDX_THEN:
            continue
        ctype = r[IDX_TYPE]
        then = r[IDX_THEN]
        if ctype in OVERDESIGN_EXEMPT_TYPES:
            continue
        has_business = any(re.search(p, then) for p in BUSINESS_ANCHORS)
        if not has_business:
            suspects.append("行%d: 疑似过度设计（Then 无业务锚点：无接口码/状态/数据/日志/MQ/缓存/业务数值/业务反馈；属0.1禁止的无业务价值测试）" % i)
    return len(suspects), suspects


def check_requirement_id(data_rows):
    """关联需求ID 追溯失效检测（软判定，对应 modeling.md 20.2）。
    信号：全员均为笼统占位（见需求文档'需求内容'/见需求文档/无），或全员相同且为占位形式
    → 需求条目级追溯失效，'每需求≥1用例'无法闭环。"""
    if not data_rows:
        return 0, []
    req_ids = [r[IDX_REQ].strip() if len(r) > IDX_REQ else "" for r in data_rows]
    suspects = []
    vague_count = sum(1 for rid in req_ids if any(re.match(p, rid) for p in VAGUE_REQ_PATTERNS))
    if req_ids and vague_count == len(req_ids):
        suspects.append("全部 %d 条关联需求ID均为笼统占位（见需求文档'需求内容'/'见需求文档'/'无'），"
                        "需求条目级追溯失效；应填具体编号或'见需求文档<章节号/章节名>'" % vague_count)
    elif len(set(req_ids)) == 1 and req_ids[0] and "见需求文档" in req_ids[0]:
        suspects.append("全部用例关联需求ID相同（'%s'），未做需求条目级区分，追溯失效" % req_ids[0])
    return len(suspects), suspects


def row_text(r):
    """用例全文（用于关键词扫描）：关联规则+模块+名称+Given+When+Then。"""
    idxs = [IDX_RULE, IDX_MOD, IDX_NAME, IDX_GIVEN, IDX_WHEN, IDX_THEN]
    return " ".join(r[i] for i in idxs if len(r) > i and r[i])


def coverage_stats(data_rows):
    """标签维度覆盖统计（原有）+ 关键词维度 + 状态机 + 边界深度(4值) + 异常子类。"""
    type_count = {}
    dim_count = {}
    level_count = {"P0": 0, "P1": 0, "P2": 0, "P3": 0}
    flow_legal = flow_illegal = flow_rollback = flow_terminal = 0
    kw_dim_count = {k: 0 for k in KEYWORD_DIMS}
    bound_total = 0
    bound_min = bound_max = bound_critical = bound_inside = 0
    exc_total = 0
    exc_subtypes_hit = {k: 0 for k in EXCEPTION_SUBTYPES}

    for r in data_rows:
        ctype = r[IDX_TYPE] if len(r) > IDX_TYPE else ""
        cdim = r[IDX_DIM] if len(r) > IDX_DIM else ""
        clevel = r[IDX_LEVEL] if len(r) > IDX_LEVEL else ""
        text = row_text(r)
        low = text.lower()

        type_count[ctype] = type_count.get(ctype, 0) + 1
        dim_count[cdim] = dim_count.get(cdim, 0) + 1
        if clevel in level_count:
            level_count[clevel] += 1

        # 关键词维度（标签无关）
        for dim, kws in KEYWORD_DIMS.items():
            if any(kw.lower() in low for kw in kws):
                kw_dim_count[dim] += 1

        # 状态机流转（识别放宽：含"状态"且含任一状态动作词，不硬要求"流转"二字）
        state_actions = FLOW_LEGAL + FLOW_ILLEGAL + FLOW_ROLLBACK + [
            "变更", "退回", "变为", "置为", "生效", "停用", "启用",
            "提交审核", "审核通过", "审核驳回", "不可直接编辑", "不可编辑", "不可删",
        ]
        is_state = (ctype == "状态迁移") or ("状态" in text and any(w in text for w in state_actions))
        if is_state:
            if any(w in text for w in FLOW_ILLEGAL):
                flow_illegal += 1
            elif any(w in text for w in FLOW_ROLLBACK):
                flow_rollback += 1
            else:
                flow_legal += 1
            if any(w in text for w in FLOW_TERMINAL):
                flow_terminal += 1

        # 边界深度
        is_boundary = (ctype == "边界") or any(kw in text for kw in BOUNDARY_KEYWORDS)
        if is_boundary:
            bound_total += 1
            if any(kw in text for kw in BOUNDARY_MIN_KW):
                bound_min += 1
            if any(kw in text for kw in BOUNDARY_MAX_KW):
                bound_max += 1
            if any(kw in text for kw in BOUNDARY_CRITICAL_KW):
                bound_critical += 1
            if any(kw in text for kw in BOUNDARY_INSIDE_KW):
                bound_inside += 1

        # 异常子类
        is_exception = (ctype == "异常") or any(kw in text for kw in ["失败", "拦截", "错误", "非法", "异常", "超时"])
        if is_exception:
            exc_total += 1
            for sub, kws in EXCEPTION_SUBTYPES.items():
                if any(kw.lower() in low for kw in kws):
                    exc_subtypes_hit[sub] += 1

    return {
        "n": len(data_rows),
        "type_count": type_count,
        "dim_count": dim_count,
        "level_count": level_count,
        "flow_legal": flow_legal, "flow_illegal": flow_illegal,
        "flow_rollback": flow_rollback, "flow_terminal": flow_terminal,
        "kw_dim_count": kw_dim_count,
        "bound_total": bound_total, "bound_min": bound_min,
        "bound_max": bound_max, "bound_critical": bound_critical,
        "bound_inside": bound_inside,
        "exc_total": exc_total, "exc_subtypes_hit": exc_subtypes_hit,
    }


def parse_rule_categories(lines):
    """从 .md 的'规则建模'section 提取规则类别（粗体标题项）。返回类别列表。
    section 位于用例表之前，标题含'规则建模'/'业务规则'/'规则'。"""
    in_section = False
    categories = []
    for ln in lines:
        s = ln.strip()
        if s.startswith("|") and "用例ID" in s:
            break  # 进入用例表，section 结束
        if re.match(r"^#+\s*.*(规则建模|业务规则|规则模型|建模)", s):
            in_section = True
            continue
        if not in_section:
            continue
        # 跳过空行/其他小标题
        if not s or s.startswith("#"):
            continue
        # - **统计规则**：...  或 **统计规则**：...
        m = re.match(r"^[-*]?\s*\*\*([^*：:]{2,20})\*\*", s)
        if m:
            categories.append(m.group(1).strip())
            continue
        # 1. 统计规则：...
        m2 = re.match(r"^\d+[.、]\s*\*\*?([^*：:（(]{2,20})", s)
        if m2:
            categories.append(m2.group(1).strip())
    return categories


def tokens_of(cat):
    """提取类别的匹配 token：英文≥2 + 中文 2-gram（用于宽松匹配，降低漏报）。"""
    toks = list(re.findall(r"[A-Za-z]{2,}", cat))
    for s in re.findall(r"[一-龥]+", cat):
        if len(s) >= 2:
            for i in range(len(s) - 1):
                toks.append(s[i:i + 2])
            if len(s) == 2:
                toks.append(s)
    return toks or [cat]


def rule_coverage(data_rows, categories):
    """检查每个规则类别是否被用例覆盖（token 宽松匹配）。返回 (未覆盖类别, 总类别数)。"""
    if not categories:
        return None, 0
    case_texts = [row_text(r) for r in data_rows]
    uncovered = []
    for cat in categories:
        toks = tokens_of(cat)
        covered = any(any(tok in ct for tok in toks) for ct in case_texts)
        if not covered:
            uncovered.append(cat)
    return uncovered, len(categories)


def parse_section_rows(lines, title_pattern, header_keywords):
    """找到标题匹配 title_pattern 的 section，解析其后的首个表格，返回数据行列表。
    header_keywords 用于确认表头是目标表格。找不到返回 []。"""
    in_section = False
    found_table = False
    rows = []
    for ln in lines:
        s = ln.strip()
        if not in_section:
            if re.match(r"^#+\s*.*(" + title_pattern + ")", s):
                in_section = True
            continue
        # in_section：遇到下一个标题则停止
        if re.match(r"^#+\s", s):
            break
        if s.startswith("|"):
            cells = split_row(s)
            if cells is None or is_separator(cells):
                continue
            # 用例表（15列，首列"用例ID"）出现在 section 内 -> section 结束，避免把用例表吃进规则/风险/测试点清单
            if cells and cells[0].strip() == "用例ID":
                break
            if not found_table:
                joined = "".join(cells)
                if any(kw in joined for kw in header_keywords):
                    found_table = True
                continue
            rows.append(cells)
        elif found_table and s and not s.startswith("|"):
            break
    return rows


def risk_coverage(data_rows, risk_rows):
    """校验每个 P0/P1 风险是否被用例覆盖。优先 ID 精确匹配（关联规则列含 R<序号>，
    R1 后非数字避免 R10 误匹配），未标注 ID 时降级 token 兜底（标注"疑似"）。
    risk_rows: [[风险ID, 风险等级, 风险描述, ...], ...]
    返回 (未覆盖列表, P0/P1总数, 风险总数)。无风险清单时返回 (None, 0, 0)。"""
    if not risk_rows:
        return None, 0, 0
    case_rule_texts = [r[IDX_RULE] if len(r) > IDX_RULE else "" for r in data_rows]
    case_full_texts = [row_text(r) for r in data_rows]
    uncovered = []
    p0p1_total = 0
    for rr in risk_rows:
        rid = rr[0].strip() if len(rr) > 0 else ""
        level = rr[1].strip() if len(rr) > 1 else ""
        desc = rr[2].strip() if len(rr) > 2 else ""
        if level not in ("P0", "P1"):
            continue
        p0p1_total += 1
        # 优先 ID 精确匹配：关联规则列含 rid 且后非数字
        id_covered = bool(rid) and any(re.search(re.escape(rid) + r"(?!\d)", rule_text) for rule_text in case_rule_texts)
        if id_covered:
            continue
        # 兜底 token 匹配
        toks = tokens_of(desc) if desc else ([rid] if rid else [])
        token_covered = any(any(tok in ct for tok in toks) for ct in case_full_texts)
        if not token_covered:
            uncovered.append("%s[%s] %s" % (rid, level, desc[:24]))
    return uncovered, p0p1_total, len(risk_rows)


def testpoint_coverage(data_rows, tp_rows):
    """校验每个测试点是否被用例覆盖。优先 ID 精确匹配（关联规则列含 TP<序号>，
    TP1 后非数字避免 TP10 误匹配），未标注 ID 时降级 token 兜底（标注"疑似"）。
    tp_rows: [[测试点ID, 场景类型, 测试点描述, ...], ...]
    返回 (未覆盖列表, 测试点总数)。无测试点清单时返回 (None, 0)。"""
    if not tp_rows:
        return None, 0
    case_rule_texts = [r[IDX_RULE] if len(r) > IDX_RULE else "" for r in data_rows]
    case_full_texts = [row_text(r) for r in data_rows]
    uncovered = []
    for tr in tp_rows:
        tpid = tr[0].strip() if len(tr) > 0 else ""
        desc = tr[2].strip() if len(tr) > 2 else (tr[1].strip() if len(tr) > 1 else "")
        # 优先 ID 精确匹配
        id_covered = bool(tpid) and any(re.search(re.escape(tpid) + r"(?!\d)", rule_text) for rule_text in case_rule_texts)
        if id_covered:
            continue
        # 兜底 token 匹配
        toks = tokens_of(desc) if desc else ([tpid] if tpid else [])
        token_covered = any(any(tok in ct for tok in toks) for ct in case_full_texts)
        if not token_covered:
            uncovered.append("%s %s" % (tpid, desc[:24]))
    return uncovered, len(tp_rows)


# ===== 新增软性检查（不改变退出码·供 selfcheck 决策）=====
# 检查13 断言完整性 / 检查9增强 存储schema交叉 / 风险来源待确认 / #4 反向需求追溯

# 检查13：状态变更动词（When 含其一 → 视为状态变更类用例，须双重断言）
STATE_CHANGE_VERBS = [
    "创建", "新增", "提交", "支付", "扣减", "扣", "更新", "修改", "删除", "撤销",
    "退款", "发货", "确认", "审核", "审批", "上架", "下架", "启用", "停用", "签收", "收货",
]
# 检查13：数据/状态副作用信号（Then 含其一 → 视为已断言副作用）
SIDE_EFFECT_SIGNALS = [
    "状态", "更新为", "变为", "置为", "减少", "增加", "未创建", "不新增", "无重复",
    "记录", "退回", "恢复", "余额", "库存", "数量", "积分", "主存储", "消息事件",
]


def check_assertion_completeness(data_rows):
    """检查13 断言完整性（软判定）。状态变更类用例（When 含状态变更动词）的 Then
    须同时含接口结果 + 数据/状态副作用；仅有接口结果、缺副作用 → 疑似不完整 oracle。
    防'测试通过却漏 bug'（见 modeling.md 13.3、selfcheck.md 检查13）。"""
    suspects = []
    for i, r in enumerate(data_rows, 1):
        if len(r) <= IDX_THEN:
            continue
        when = r[IDX_WHEN]
        then = r[IDX_THEN]
        if not any(v in when for v in STATE_CHANGE_VERBS):
            continue
        has_interface = bool(re.search(
            r"(HTTP|状态码|返回\s*\d{3}|错误码|status\s*=|code\s*=|\b[45]\d{2}\b)",
            then, flags=re.IGNORECASE))
        has_sideeffect = any(s in then for s in SIDE_EFFECT_SIGNALS)
        if has_interface and not has_sideeffect:
            suspects.append("行%d: 状态变更类用例 Then 仅有接口结果，缺数据/状态副作用断言（检查13）" % i)
    return len(suspects), suspects


# ===== 检查15：业务行为来源追溯（#5·破脑补·软判定）=====
# 口径来自 validation_rules.json 的 behavior_source（单一事实源），与 selfcheck.md 检查15、
# dedup_coverage.md #5 反向行为来源追溯、SKILL.md 0.9 一致。本检查闭合 0.3/0.4 脑补禁令在
# "业务行为"维度的机械缺口：用例 Given/When/Then 断言的业务行为须能追溯到
# 需求文档 / 规则建模·风险清单（R/TP 引用）/ 已登记假设（假设A 标记），三者皆无即疑似脑补。
_BS = _RULES.get("behavior_source", {})
BEHAVIOR_SIGNALS = list(_BS.get("behavior_signals", []))
_STATE_TARGET_PAT = re.compile(
    _BS.get("state_target_pattern", r"状态(由|变更为|更新为|变为|置为|保持为)([一-龥A-Za-z0-9]{2,8})"))
_ASSUMPTION_TAG_PATS = [re.compile(p) for p in _BS.get("assumption_tag_patterns", [r"假设A\d+", r"基于假设"])]
_CITATION_PAT = re.compile(_BS.get("citation_pattern", r"(R|TP)\d+"))
_SOURCE_MARKER_PAT = re.compile(_BS.get("source_marker_pattern", r"来源[:：]"))

# ===== #6 反向接口追溯（契约驱动分支·变更影响清单 -> 用例三类覆盖）=====
# 变更类型枚举（config/validation_rules.json change_types）；非空时校验变更影响清单的变更类型列
CHANGE_TYPES = set(_RULES.get("change_types", []))

# 契约类覆盖信号（扫描引用本变更接口的用例文本）
CONTRACT_PRESENCE_TOKENS = ["不传", "未传", "缺失", "必填缺失", "未提供", "为空", "空值"]
CONTRACT_TYPE_TOKENS = ["类型错传", "类型不匹配", "类型错误", "异型", "类型非法"]
CONTRACT_OUTPUT_TOKENS = ["错误码", "状态码", "返回", "status", "code", "400", "403", "409", "500", "200"]


def _cases_citing(data_rows, pattern_id):
    """返回关联规则列精确引用 pattern_id（如 API1/R3/SC2，后非数字避免 API10 误匹配 API1）的用例行。"""
    if not pattern_id:
        return []
    pat = re.compile(re.escape(pattern_id) + r"(?!\d)")
    return [r for r in data_rows if len(r) > IDX_RULE and pat.search(r[IDX_RULE] or "")]


def parse_interface_changes(lines):
    """解析'变更影响清单'section（接口契约模型），返回变更接口数据行。
    表头含 接口ID|接口名/路径|方法|变更类型|变更描述|变更字段|受影响规则|受影响场景|风险等级|来源。
    无该 section 返回 []。"""
    return parse_section_rows(lines, "变更影响清单|接口契约模型|变更接口清单", ["接口ID", "接口名"])


def reverse_interface_trace(data_rows, lines):
    """#6 反向接口追溯（软判定）：对每个变更接口核查 契约类(A-F) + 规则类(G) + 场景类(H) 覆盖。
    契约类：引用本 API<序号> 的用例须覆盖 presence(不传/缺失) + type(类型错传) + 出参(错误码/状态码)。
    规则类：该接口"受影响规则"列的每个 R<序号> 须有用例引用覆盖。
    场景类：该接口"受影响场景"列的每个 SC<序号> 须有用例引用覆盖。
    无受影响规则->跳规则类；无受影响场景->跳场景类。无变更影响清单->返回 ([], 0, [])。
    返回 (未覆盖列表, 变更接口总数, 变更类型越界列表)。"""
    api_rows = parse_interface_changes(lines)
    if not api_rows:
        return [], 0, []
    uncovered = []
    ctype_issues = []
    for ar in api_rows:
        api_id = ar[0].strip() if len(ar) > 0 else ""
        path = ar[1].strip() if len(ar) > 1 else ""
        method = ar[2].strip() if len(ar) > 2 else ""
        ctype = ar[3].strip() if len(ar) > 3 else ""
        affected_rules = ar[6].strip() if len(ar) > 6 else ""
        affected_scenarios = ar[7].strip() if len(ar) > 7 else ""
        if CHANGE_TYPES and ctype and ctype not in CHANGE_TYPES:
            ctype_issues.append("接口[%s] 变更类型『%s』不在枚举内" % (api_id or path, ctype))
        cases = _cases_citing(data_rows, api_id) if api_id else []
        joined = " ".join(row_text(r) for r in cases)
        miss = []
        if not any(t in joined for t in CONTRACT_PRESENCE_TOKENS):
            miss.append("契约-存在性(不传/缺失)")
        if not any(t in joined for t in CONTRACT_TYPE_TOKENS):
            miss.append("契约-类型(类型错传)")
        if not any(t in joined for t in CONTRACT_OUTPUT_TOKENS):
            miss.append("契约-出参(错误码/状态码)")
        if affected_rules:
            rule_ids = re.findall(r"R\d+", affected_rules)
            unc_r = [rid for rid in rule_ids if not _cases_citing(data_rows, rid)]
            if unc_r:
                miss.append("规则类未覆盖%s" % "/".join(unc_r))
        if affected_scenarios:
            sc_ids = re.findall(r"SC\d+", affected_scenarios)
            unc_s = [sid for sid in sc_ids if not _cases_citing(data_rows, sid)]
            if unc_s:
                miss.append("场景类未覆盖%s" % "/".join(unc_s))
        if miss:
            uncovered.append("%s %s %s 缺:%s" % (api_id, method, path, ";".join(miss)))
    return uncovered, len(api_rows), ctype_issues


def extract_behavior_signals(text):
    """从用例文本抽取业务行为信号：状态流转目标态 + 模态/约束/机制信号词。返回信号集合。"""
    if not text:
        return set()
    sigs = set()
    for m in _STATE_TARGET_PAT.finditer(text):
        target = m.group(2)
        if target:
            sigs.add(target)
    for w in BEHAVIOR_SIGNALS:
        if w in text:
            sigs.add(w)
    return sigs


def _has_assumption_tag(case_cells):
    """用例是否含假设标记（假设A1/基于假设），查关联规则列与用例名称列。"""
    for idx in (IDX_RULE, IDX_NAME):
        if len(case_cells) > idx:
            t = case_cells[idx] or ""
            if any(p.search(t) for p in _ASSUMPTION_TAG_PATS):
                return True
    return False


def _has_rule_citation(case_cells):
    """用例关联规则列是否引用 R<序号>/TP<序号>（追溯到规则建模/风险/测试点清单）。"""
    if len(case_cells) > IDX_RULE:
        return bool(_CITATION_PAT.search(case_cells[IDX_RULE] or ""))
    return False


def check_behavior_source_lines(data_rows, req_doc_text):
    """检查15 业务行为来源追溯（#5·软判定）的内存入口：接受预读的需求文档全文文本
    而非文件路径。check_behavior_source(data_rows, req_doc_path) 读盘后委托本函数。
    语义/返回与原实现一致：返回 (疑似条数, 疑似列表, 是否提供了可读需求文档)。
    req_doc_text 为空串时退回 (b)(c) 判定（无法做 a 的 token 核对，has_req=False）。"""
    req_text = req_doc_text or ""
    has_req = req_text != ""
    suspects = []
    for i, r in enumerate(data_rows, 1):
        if len(r) <= IDX_THEN:
            continue
        case_text = " ".join(r[IDX_GIVEN:IDX_THEN + 1])
        sigs = extract_behavior_signals(case_text)
        if not sigs:
            continue  # 无业务行为信号，不判
        if _has_rule_citation(r) or _has_assumption_tag(r):
            continue  # 已引用 R/TP 或已标假设 -> 视为已登记来源
        # 无引用、无假设：行为信号须出现在需求文档，否则疑似脑补
        ungrounded = sorted(s for s in sigs if s and s not in req_text)
        if ungrounded:
            suspects.append("行%d: 疑似无来源业务行为（检查15）：未引用R/TP、无假设标记，且行为信号[%s]不在需求文档->需转问题/假设"
                            % (i, "/".join(ungrounded)[:60]))
    return len(suspects), suspects, has_req


def check_behavior_source(data_rows, req_doc_path):
    """检查15 业务行为来源追溯（#5·软判定）。文件入口（Phase 13 回读用）：
    读需求文档文件后委托 check_behavior_source_lines。返回语义不变。
    （实现见 check_behavior_source_lines 的文档注释。）"""
    req_text = ""
    if req_doc_path and os.path.exists(req_doc_path):
        try:
            with open(req_doc_path, "r", encoding="utf-8") as f:
                req_text = f.read()
        except Exception:
            req_text = ""
    return check_behavior_source_lines(data_rows, req_text)


def check_rule_source(lines):
    """检查15 增强（规则来源·破自证循环·软判定）。规则建模 section 每条规则项建议标注来源
    （来源:需求文档<章节>/台账Q<序号>/假设A<序号>）。无来源标记 -> 疑似脑补规则。
    规则建模 section 由模型自写，若无来源约束会被 rule_coverage 反向洗白为"已覆盖"，
    本检查补该缺口（根因5 自证循环）。无规则建模 section 或无可解析项 -> 跳过（返回 0,[]）。"""
    in_section = False
    items = []
    for ln in lines:
        s = ln.strip()
        if s.startswith("|") and "用例ID" in s:
            break
        if re.match(r"^#+\s*.*(规则建模|业务规则|规则模型|建模)", s):
            in_section = True
            continue
        if not in_section:
            continue
        if not s or s.startswith("#"):
            continue
        if re.match(r"^[-*]?\s*\*\*([^*：:]{2,20})\*\*", s) or re.match(r"^\d+[.、]\s*\*\*?([^*：:（(]{2,20})", s):
            items.append(s)
    if not items:
        return 0, []
    suspects = []
    for it in items:
        if not _SOURCE_MARKER_PAT.search(it):
            m = re.match(r"^[-*]?\s*\*\*([^*：:]{2,20})\*\*", it) or \
                re.match(r"^\d+[.、]\s*\*\*?([^*：:（(]{2,20})", it)
            name = m.group(1).strip() if m else it[:20]
            suspects.append("规则项[%s] 无来源标记（建议补 来源:需求文档<章节>/台账Q<n>/假设A<n>，破自证循环）" % name)
    return len(suspects), suspects


def parse_tech_impl_names(lines):
    """解析可选'技术实现摘要'section（§5 提供），提取明确提供的存储名清单
    （表名/字段/Key/Topic/Index/Bucket）。section 标题含'技术实现'，其后表格/列表。
    无该 section 返回 []（检查9增强退回正则兜底）。"""
    in_section = False
    names = []
    for ln in lines:
        s = ln.strip()
        if not in_section:
            if re.match(r"^#+\s*.*技术实现", s):
                in_section = True
            continue
        if re.match(r"^#+\s", s):
            break
        # 命中存储模式的 token
        for pat, _ in STORAGE_PATTERNS:
            for m in re.finditer(pat, s, flags=re.IGNORECASE):
                names.append(m.group(0).strip())
        # 反引号/引号包裹的标识符
        for m in re.finditer(r"[`'\"]([a-zA-Z_][a-zA-Z0-9_]{2,})[`'\"]", s):
            names.append(m.group(1))
    return list(set(names))


def check_storage_schema(data_rows, lines):
    """检查9 增强（软判定）：若 .md 含'技术实现摘要'section（§5 提供真实 schema），
    则对命中存储模式的断言名做清单交叉校验——不在清单内 → 疑似杜撰。
    无清单则返回 (None, [])，退回 check_storage 现有正则判定，行为不变。"""
    allowlist = parse_tech_impl_names(lines)
    if not allowlist:
        return None, []
    allow_lower = [a.lower() for a in allowlist]
    suspects = []
    for i, r in enumerate(data_rows, 1):
        if len(r) <= IDX_THEN:
            continue
        text = " ".join(r[IDX_GIVEN:IDX_THEN + 1])
        for pat, desc in STORAGE_PATTERNS:
            for m in re.finditer(pat, text, flags=re.IGNORECASE):
                name = m.group(0).strip()
                if name.lower() not in allow_lower:
                    suspects.append("行%d: %s『%s』不在技术实现摘要清单内（疑似杜撰，检查9增强）" % (i, desc, name))
    return len(suspects), suspects


# 风险来源：需在台账由对应角色确认的来源
ROLE_SOURCES = ("技术隐含@开发", "业务领域@业务", "缺陷反哺")


def risk_source_report(risk_rows):
    """风险来源分布 + 待台账角色确认列表（软提示）。对来源∈{技术隐含@开发,业务领域@业务,缺陷反哺}
    的 P0/P1 风险，提示需在澄清台账由对应角色确认（见 risk.md 三源共验、clarification.md 角色路由）。
    risk_rows 第5列为'风险来源'（若存在）。返回 (分布dict, 待确认列表)。"""
    dist = {}
    pending = []
    if not risk_rows:
        return dist, pending
    for rr in risk_rows:
        rid = rr[0].strip() if len(rr) > 0 else ""
        level = rr[1].strip() if len(rr) > 1 else ""
        source = rr[4].strip() if len(rr) > 4 and rr[4].strip() else "需求推导"
        dist[source] = dist.get(source, 0) + 1
        if level in ("P0", "P1") and source in ROLE_SOURCES:
            pending.append("%s[%s] 来源=%s（需在台账确认）" % (rid, level, source))
    return dist, pending


def parse_requirement_items_from_lines(rlines):
    """从已读入的需求文档行列表提取需求条目（标题行 # + 显式编号 REQ-xxx / 需求N）。
    返回 [(条目标识, 原行)]。空列表返回 []。parse_requirement_items(req_doc_path)
    读盘后委托本函数；供内存内 gate 调用（#4 反向需求追溯无需落盘需求文档）。"""
    items = []
    heading_level = 99
    for ln in rlines:
        s = ln.strip()
        m = re.match(r"^(#{1,4})\s+(.+)", s)
        if m:
            lvl = len(m.group(1))
            title = m.group(2).strip()
            # 跳过文档根标题（# 一级），只取二级及以下章节为需求条目
            if lvl == 1:
                continue
            if lvl < heading_level:
                heading_level = lvl
            items.append(("标题:%s" % title, s))
            continue
        m = re.match(r"^(REQ[-_]?[A-Za-z0-9\-_]+|需求\s*\d+)[.、:：\s]", s)
        if m:
            items.append((m.group(1).strip(), s))
    return items


def parse_requirement_items(req_doc_path):
    """从需求文档提取需求条目。文件入口（Phase 13 回读用）：读盘后委托
    parse_requirement_items_from_lines。返回 [(条目标识, 原行)]，文件不存在/不可读返回 []。"""
    if not req_doc_path or not os.path.exists(req_doc_path):
        return []
    try:
        with open(req_doc_path, "r", encoding="utf-8") as f:
            rlines = f.readlines()
    except Exception:
        return []
    return parse_requirement_items_from_lines(rlines)


def _req_item_tokens(item_id):
    """从需求条目标识抽取匹配 token（供 #4 反向需求追溯的宽松匹配）。
    标题条目（"标题:xxx"）切为：英文/数字≥2 连续段 + 中文 2-gram 滑动窗。
    用 2-gram 滑动窗而非整段 CJK run，使 20.2 推荐的短写法（如"见需求文档3.2订单创建"）
    能命中长标题（如"3.2 订单创建功能"）——整段 run "订单创建功能"无法成为短写法的子串，
    而 2-gram "订单""创建"等可命中。数字/章节号单独成 token 以支持"3.2"定位。
    非"标题:"条目（REQ-xxx/需求N）返回原 item_id，由调用方做精确子串匹配。"""
    body = item_id[3:] if item_id.startswith("标题:") else item_id
    toks = []
    # 英文≥2 连续段（含点号，如 "REQ-ORD" / "API1"）
    for m in re.findall(r"[A-Za-z][A-Za-z0-9_\-]{1,}", body):
        toks.append(m)
    # 数字串（含点号分隔，如 "3.2" / "001"），便于按章节号定位
    for m in re.findall(r"\d+(?:\.\d+)*", body):
        toks.append(m)
    # 中文 2-gram 滑动窗（"订单创建功能" → 订单/单创/创建/建功/功能）
    for s in re.findall(r"[一-龥]+", body):
        if len(s) >= 2:
            for i in range(len(s) - 1):
                toks.append(s[i:i + 2])
            if len(s) == 2:
                toks.append(s)
    # 去重保序，保留信息量大的前若干个（防 token 过多误命中）
    seen = set()
    uniq = []
    for t in toks:
        if t and t not in seen:
            seen.add(t)
            uniq.append(t)
    return uniq[:6]


def reverse_requirement_trace(data_rows, req_doc_path):
    """#4 反向需求追溯（软判定）：需求文档每条条目须有≥1用例引用（关联需求ID列）。
    未被引用的条目列为'未覆盖需求'。无需求文档（未传第2参数）则跳过，返回 (None, 0)。"""
    items = parse_requirement_items(req_doc_path)
    if not items:
        return None, 0
    req_ids = [r[IDX_REQ].strip() if len(r) > IDX_REQ else "" for r in data_rows]
    uncovered = []
    for item_id, _ in items:
        if item_id.startswith("标题:"):
            toks = _req_item_tokens(item_id)
            if toks and not any(any(tok in rid for tok in toks) for rid in req_ids):
                uncovered.append(item_id)
        else:
            if not any(item_id in rid for rid in req_ids):
                uncovered.append(item_id)
    return uncovered, len(items)


def reverse_requirement_trace_items(data_rows, req_items):
    """#4 反向需求追溯的内存入口：接受预解析的需求条目（parse_requirement_items_from_lines
    的返回值）而非文件路径。供内存内 gate（Phase 8）调用，无需落盘需求文档。
    无条目则跳过，返回 (None, 0)。"""
    if not req_items:
        return None, 0
    req_ids = [r[IDX_REQ].strip() if len(r) > IDX_REQ else "" for r in data_rows]
    uncovered = []
    for item_id, _ in req_items:
        if item_id.startswith("标题:"):
            toks = _req_item_tokens(item_id)
            if toks and not any(any(tok in rid for tok in toks) for rid in req_ids):
                uncovered.append(item_id)
        else:
            if not any(item_id in rid for rid in req_ids):
                uncovered.append(item_id)
    return uncovered, len(req_items)


def collect_all_findings(data_rows, lines, req_doc_lines=None):
    """把全部检查/统计/追溯一次性计算并聚合成结构化 dict（不打印）。
    供内存内 gate（Phase 8 出口 gate）与文件入口（Phase 13 回读）共用同一计算，
    保证"写前内存校验"与"写后回读校验"判定口径完全一致。

    参数：
      data_rows: parse_table_from_lines 返回的用例行列表
      lines: 同一份 .md 的全部行（供 section 解析）
      req_doc_lines: 可选，预读的需求文档行列表；非 None 且非空时启用 #4 反向需求追溯
                     + #5 业务行为 token 核对；为 None 时这两项跳过（与 Phase 13
                     "未传第2参数则跳过"语义一致）

    返回 dict：
      {n, hard_violations,
       soft:{assertions:[n,list], storage:[n,list], schema:[n_or_None,list],
             dups:[n,list], overdesign:[n,list], reqid:[n,list],
             completeness:[n,list], behavior:[n,list,has_req], rule_source:[n,list]},
       coverage:<coverage_stats dict>,
       traces:{rule:[uncovered_or_None,total], risk:[uncovered_or_None,p0p1,total],
               testpoint:[uncovered_or_None,total],
               interface:[uncovered_list,api_total,ctype_issues],
               requirement:[uncovered_or_None,total]},
       risk_source:[dist_dict,pending_list]}

    设计约束（不可违背）：
    * 不改任何 check_* 函数签名/返回/逻辑——本函数只做调用与聚合
    * 不打印——打印由调用方负责（main() 走 print_findings，gate 走 dict 读取）
    * hard_violations = check_ids + check_fields，与 main() 一致
    """
    # 硬性校验
    id_violations = check_ids(data_rows)
    field_violations = check_fields(data_rows)
    hard_violations = id_violations + field_violations

    # 软性校验
    assert_n, assert_list = check_assertions(data_rows)
    storage_n, storage_list = check_storage(data_rows)
    schema_n, schema_list = check_storage_schema(data_rows, lines)
    dup_n, dup_list = check_duplicates(data_rows)
    overdesign_n, overdesign_list = check_overdesign(data_rows)
    reqid_n, reqid_list = check_requirement_id(data_rows)
    complete_n, complete_list = check_assertion_completeness(data_rows)
    if req_doc_lines is not None:
        req_doc_text = "".join(req_doc_lines) if req_doc_lines else ""
        behsrc_n, behsrc_list, has_req = check_behavior_source_lines(data_rows, req_doc_text)
        req_items = parse_requirement_items_from_lines(req_doc_lines or [])
        unc_req, req_total = reverse_requirement_trace_items(data_rows, req_items)
    else:
        # 未提供需求文档：#5 退回 (b)(c) 判定（无 token 核对，has_req=False），
        # #4 跳过。与 Phase 13 "未传第2参数"行为一致。
        behsrc_n, behsrc_list, has_req = check_behavior_source_lines(data_rows, "")
        unc_req, req_total = None, 0
    rulesrc_n, rulesrc_list = check_rule_source(lines)

    # 覆盖统计
    stats = coverage_stats(data_rows)

    # 追溯
    categories = parse_rule_categories(lines)
    unc_rule, total_cat = rule_coverage(data_rows, categories)
    risk_rows = parse_section_rows(lines, "风险清单|风险分析|风险列表", ["风险ID", "风险等级"])
    unc_risk, p0p1_total, risk_total = risk_coverage(data_rows, risk_rows)
    tp_rows = parse_section_rows(lines, "测试点清单|测试点列表|测试点建模", ["测试点ID", "测试点"])
    unc_tp, tp_total = testpoint_coverage(data_rows, tp_rows)
    unc_api, api_total, ctype_issues = reverse_interface_trace(data_rows, lines)
    src_dist, src_pending = risk_source_report(risk_rows)

    return {
        "n": len(data_rows),
        "hard_violations": hard_violations,
        "soft": {
            "assertions": [assert_n, assert_list],
            "storage": [storage_n, storage_list],
            "schema": [schema_n, schema_list],
            "dups": [dup_n, dup_list],
            "overdesign": [overdesign_n, overdesign_list],
            "reqid": [reqid_n, reqid_list],
            "completeness": [complete_n, complete_list],
            "behavior": [behsrc_n, behsrc_list, has_req],
            "rule_source": [rulesrc_n, rulesrc_list],
        },
        "coverage": stats,
        "traces": {
            "rule": [unc_rule, total_cat],
            "risk": [unc_risk, p0p1_total, risk_total],
            "testpoint": [unc_tp, tp_total],
            "interface": [unc_api, api_total, ctype_issues],
            "requirement": [unc_req, req_total],
        },
        "risk_source": [src_dist, src_pending],
    }


def run_inmemory(lines, req_doc_lines=None):
    """内存内全量校验入口（Phase 8 出口 gate 调用，零文件操作）。
    输入：lines=Write 即将落盘的完整 .md 文本（按行）；
          req_doc_lines=可选，预读的需求文档行列表（启用 #4/#5）。
    输出：(parsed, findings_dict)：
      parsed=None 且 findings=None -> 表头解析失败（gate 须提示结构缺陷）；
      否则 findings=collect_all_findings 的 dict。
    与文件入口 main() 口径一致：同一份文本经 run_inmemory 与经
    `python verify_cases.py <file> [req.md]` 的判定结果相同。"""
    parsed, err = parse_table_from_lines(lines)
    if parsed is None:
        return None, None
    _header, data_rows, _lines = parsed
    findings = collect_all_findings(data_rows, lines, req_doc_lines=req_doc_lines)
    return parsed, findings


def dump_rules():
    """打印校验规则契约（内容来自 config/validation_rules.json，单一事实源）。
    供 agent 在设计用例前读取，替代阅读本脚本源码：拿到枚举/正则/关键词/section 格式
    即可写出一次过的用例，避免因漏读校验口径导致整文件重写。输出始终与 _RULES 同步。"""
    r = _RULES
    print("===== 校验规则契约（单一事实源 config/validation_rules.json）=====")
    print("-- 由 `verify_cases.py --dump-rules` 输出；agent 设计用例前读本契约即可，无需读脚本源码 --")
    print()
    print("【15列表头顺序】(用例表必须15列、顺序一致；列数不足/错位硬阻断 exit=1)")
    print("  " + " | ".join(r["header"]))
    fc = r["fixed_columns"]
    print("【固定值列】编辑模式=%s | 标签=%s | 责任人=%s | 用例状态=%s（逐行填写，禁改值）" % (
        fc["edit_mode"], fc["tag"], fc["owner"], fc["status"]))
    print()
    print("【测试类型枚举】(测试类型列，越界即 exit=1)")
    print("  " + " / ".join(r["valid_types"]))
    print("【测试维度枚举】(测试维度列，越界即 exit=1)")
    print("  " + " / ".join(r["valid_dims"]))
    print("【用例等级】" + " / ".join(r["valid_levels"]) + "（取自第5阶段风险分析）")
    print("【用例名称】%d段【模块】【功能】【场景】【预期】，缺段硬阻断" % r["name_segments"])
    print("【用例ID】<需求标识>_<功能缩写>_<序号>，按功能缩写分组连续不跳号，跨文件全局唯一")
    print()
    print("【关联需求ID】填具体编号或'见需求文档<章节号/章节名>'；下列占位全员命中→追溯失效：")
    print("  " + " | ".join(r["vague_req_patterns"]))
    print()
    print("【断言可观测(Then)】Then 须命中以下任一锚点，否则疑似不可观测（软判定）：")
    print("  " + " / ".join(r["observable_patterns"]))
    print("【模糊词(禁止出现在Then)】" + " / ".join(r["vague_words"]))
    print()
    print("【存储合规】禁止杜撰表名/字段/Redis Key/Topic/Index/Bucket；疑似模式：")
    for s in r["storage_patterns"]:
        print("  %-28s → %s" % (s["pattern"], s["desc"]))
    print("  需求未提供存储名时用自然语言：" + " / ".join(r["storage_natural"]))
    print()
    hv = set(r["high_value_dims"])
    print("【关键词维度(覆盖统计，扫描用例全文；对标签错标鲁棒)】高价值维度=0 则⚠：" + "/".join(r["high_value_dims"]))
    for k, v in r["keyword_dims"].items():
        print("  %s%s: %s" % (k, "（高价值）" if k in hv else "", "/".join(v)))
    print()
    print("【状态机流转】(状态机用例>0 且 非法流转=0 时⚠)")
    print("  合法: " + "/".join(r["flow_legal"]))
    print("  非法: " + "/".join(r["flow_illegal"]))
    print("  回滚: " + "/".join(r["flow_rollback"]))
    print("  终态: " + "/".join(r["flow_terminal"]))
    print()
    print("【边界深度】(最小/最大/临界/边界内 四者任一=0 且有边界用例时⚠；边界内=min+1/max-1 刚好满足应通过)")
    print("  最小: " + "/".join(r["boundary_min_kw"]))
    print("  最大: " + "/".join(r["boundary_max_kw"]))
    print("  临界: " + "/".join(r["boundary_critical_kw"]))
    print("  边界内: " + "/".join(r["boundary_inside_kw"]))
    print("  识别词: " + "/".join(r["boundary_keywords"]))
    print()
    print("【异常子类(8类)】")
    for k, v in r["exception_subtypes"].items():
        print("  %s: %s" % (k, "/".join(v)))
    print()
    print("【过度设计】Then 无业务锚点→疑似（测试类型 %s 豁免）" % "/".join(r["overdesign_exempt_types"]))
    print("  业务锚点: " + " / ".join(r["business_anchors"]))
    print()
    print("【追溯性 section（用例表之前，强制沉淀；缺失则⚠提示补齐）】")
    print("  规则建模: 粗体项 **类别名** 或 '1. **类别名**'，每类须被用例覆盖(token宽松匹配)；每项建议标 来源:需求文档<章节>/台账Q<n>/假设A<n>（无->疑似脑补规则）")
    print("  风险清单: 表格 风险ID|风险等级|风险描述|关联模块|风险来源；用例'关联规则'列含 R<序号> 精确覆盖每个 P0/P1")
    print("    风险来源取值: 需求推导 / 技术隐含@开发 / 业务领域@业务 / 缺陷反哺（risk.md 三源共验）")
    print("  测试点清单: 表格 测试点ID|场景类型|测试点描述|关联模块；用例'关联规则'列含 TP<序号> 精确覆盖每个测试点")
    print("  变更影响清单(契约驱动分支): 表格 接口ID|接口名/路径|方法|变更类型|变更描述|变更字段|受影响规则|受影响场景|风险等级|来源")
    print("    变更类型取值: " + " / ".join(r.get("change_types", [])))
    print("    用例'关联规则'列含 API<序号> 精确覆盖每个变更接口；来源标 [需求文档<章节>/台账Q<n>/假设A<n>/接口文档<版本>/接口文档diff 旧->新]")
    print("  场景清单: 表格 场景ID|场景描述|关联模块；用例'关联规则'列含 SC<序号> 精确覆盖每个场景")
    print()
    print("【统一接口测试矩阵（契约+规则+场景·仅对变更接口/字段/受影响规则场景）】")
    print("  契约类: A入参存在性(必填不传/选填不传/多余字段) B入参类型(类型错传/三态) C值域 D组合 E出参契约 F鲁棒性 -> 追溯 API<序号>")
    print("  规则类: G业务规则(正向/异常/组合/跨字段约束) -> 追溯 R<序号>")
    print("  场景类: H业务场景(主穿越/分支/异常/上下游) -> 追溯 SC<序号>")
    print("  收敛: 只对变更字段+受影响规则/场景；P0全量/P1全量或pairwise/P2P3采样；类别不同不合并")
    print("  #6 反向接口追溯: 每个变更接口须三类覆盖(契约presence+type+出参 / 规则R / 场景SC)；无受影响规则->跳规则类，无受影响场景->跳场景类")
    print()
    print("【软性检查（新增·不改变退出码）】")
    print("  检查13 断言完整性: 状态变更类用例(When含%s) Then 须含数据/状态副作用" % "/".join(["创建","支付","扣减","更新","删除","撤销","退款","发货"]))
    print("  检查9增强 存储schema: 若 .md 含'技术实现摘要'section，断言存储名须在清单内")
    print("  风险来源待确认: 来源∈{技术隐含@开发,业务领域@业务,缺陷反哺} 的 P0/P1 须在台账角色确认")
    print("  #4 反向需求追溯: 需求文档每条目须被用例引用（传第2参数需求文档启用）")
    print("  检查15/#5 业务行为来源追溯: 用例 Given/When/Then 断言的业务行为须有来源三选一")
    print("    (a)行为 token 在需求文档/接口契约文档 | (b)关联规则引用 R<序号>/TP<序号>/API<序号> | (c)关联规则/用例名称含 假设A<序号>/基于假设")
    print("    三者皆无->疑似脑补，须转问题(P0/P1)/假设(P2/P3)，不得静默保留；行为信号: " + "/".join(r["behavior_source"]["behavior_signals"]))
    print()
    print("【domain_config.json】可选领域覆盖(同名字段替换)：business_anchors / keyword_dims / exception_subtypes / overdesign_exempt_types")
    print("=" * 64)


def print_findings(findings, basename, req_doc_lines=None):
    """打印 collect_all_findings 的结果（文件入口 Phase 13 回读用）。
    输出与重构前 main() 内联打印字节级一致（回归安全）：同一份 .md 经
    `python verify_cases.py <file>` 与重构前产出完全相同的 stdout。
    内存内 gate 不调用本函数（gate 直接读 dict 做自修决策，不打 human-facing 报告）。"""
    n = findings["n"]
    soft = findings["soft"]
    stats = findings["coverage"]
    traces = findings["traces"]
    src_dist, src_pending = findings["risk_source"]

    print("===== 用例内容校验 + 覆盖统计 =====")
    print("文件: %s" % basename)
    print("用例条数: %d" % n)
    print("-" * 48)

    # 硬性校验（注：findings.hard_violations 已含 id+field；下方分组打印需各自复取，
    # check_ids/check_fields 为纯函数幂等，与原 main 调用次序一致，回归安全）
    hard_violations = findings["hard_violations"]
    data_rows_for_hard = findings.get("_data_rows")
    id_v = check_ids(data_rows_for_hard) if data_rows_for_hard else []
    field_v = check_fields(data_rows_for_hard) if data_rows_for_hard else []
    print("【硬性校验·不通过即 exit=1】")
    print("检查5 ID唯一连续: %s" % ("通过" if not id_v else "不通过"))
    for v in id_v:
        print("  - %s" % v)
    print("检查11 字段规范(枚举/四段/固定列/等级): %s" % ("通过" if not field_v else "不通过"))
    for v in field_v:
        print("  - %s" % v)

    # 软性校验
    assert_n, assert_list = soft["assertions"]
    storage_n, storage_list = soft["storage"]
    schema_n, schema_list = soft["schema"]
    dup_n, dup_list = soft["dups"]
    overdesign_n, overdesign_list = soft["overdesign"]
    reqid_n, reqid_list = soft["reqid"]
    complete_n, complete_list = soft["completeness"]
    behsrc_n, behsrc_list, has_req = soft["behavior"]
    rulesrc_n, rulesrc_list = soft["rule_source"]
    print("-" * 48)
    print("【软性校验·列疑似条数，供 selfcheck 决策】")
    print("检查4 断言可观测: 疑似 %d 条" % assert_n)
    for v in assert_list[:10]:
        print("  - %s" % v)
    if len(assert_list) > 10:
        print("  ...（其余 %d 条略）" % (len(assert_list) - 10))
    print("检查9 存储合规: 疑似 %d 条" % storage_n)
    for v in storage_list[:10]:
        print("  - %s" % v)
    if schema_n is None:
        print("检查9增强 存储schema交叉: 跳过（未提供'技术实现摘要'section，退回正则判定）")
    else:
        print("检查9增强 存储schema交叉: 疑似 %d 条" % schema_n)
        for v in schema_list[:10]:
            print("  - %s" % v)
    print("检查6 重复用例: 疑似 %d 条" % dup_n)
    for v in dup_list[:10]:
        print("  - %s" % v)
    print("检查7 过度设计: 疑似 %d 条" % overdesign_n)
    for v in overdesign_list[:10]:
        print("  - %s" % v)
    print("关联需求ID追溯: 疑似 %d 条" % reqid_n)
    for v in reqid_list:
        print("  - %s" % v)
    print("检查13 断言完整性: 疑似 %d 条（状态变更类用例缺数据/状态副作用）" % complete_n)
    for v in complete_list[:10]:
        print("  - %s" % v)
    bs_note = "" if has_req else "（未提供需求文档，仅按 R/TP 引用与假设标记判定，无法做 token 核对）"
    print("检查15 业务行为来源追溯(#5): 疑似 %d 条（无来源业务行为）%s" % (behsrc_n, bs_note))
    for v in behsrc_list[:10]:
        print("  - %s" % v)
    if len(behsrc_list) > 10:
        print("  ...（其余 %d 条略）" % (len(behsrc_list) - 10))
    print("检查15 规则来源(破自证循环): 疑似 %d 条（规则建模项无来源标记）" % rulesrc_n)
    for v in rulesrc_list[:10]:
        print("  - %s" % v)

    # 覆盖统计
    print("-" * 48)
    print("【覆盖统计·供 selfcheck 检查2/3/8 参考】")
    print("-- 标签维度 --")
    type_n = len(stats["type_count"])
    type_warn = " ⚠种类<3，疑似单方法未组合（见 references/methods.md 多方法组合）" if type_n < 3 else ""
    print("测试类型种类: %d 种 -> %s%s" % (type_n, dict(stats["type_count"]), type_warn))
    print("测试维度种类: %d 种 -> %s" % (len(stats["dim_count"]), dict(stats["dim_count"])))
    print("风险等级分布: %s" % stats["level_count"])
    print("-- 关键词维度（对标签错标鲁棒，扫描用例全文）--")
    for dim in KEYWORD_DIMS:
        cnt = stats["kw_dim_count"][dim]
        flag = " ⚠高价值维度=0，提示按需补齐" if dim in HIGH_VALUE_DIMS and cnt == 0 else ""
        print("  %s: %d 条%s" % (dim, cnt, flag))
    print("-- 状态机流转（references/example.md 范例2）--")
    flow_total = stats["flow_legal"] + stats["flow_illegal"] + stats["flow_rollback"]
    flow_warn = "（⚠ 非法流转=0，状态机测试缺核心范式）" if flow_total > 0 and stats["flow_illegal"] == 0 else ""
    print("  合法=%d / 非法=%d / 回滚=%d / 其中终态相关=%d%s" % (
        stats["flow_legal"], stats["flow_illegal"], stats["flow_rollback"], stats["flow_terminal"], flow_warn))
    print("-- 边界深度（references/quality_rules.md 11.4 / modeling.md 边界类 4 值）--")
    if stats["bound_total"] > 0:
        depth_warn = ""
        miss = []
        if stats["bound_min"] == 0:
            miss.append("最小")
        if stats["bound_max"] == 0:
            miss.append("最大")
        if stats["bound_critical"] == 0:
            miss.append("临界")
        if stats["bound_inside"] == 0:
            miss.append("边界内")
        if miss:
            depth_warn = "（⚠ 疑似边界深度不足，缺%s）" % "/".join(miss)
        print("  边界用例 %d 条，覆盖 最小=%d / 最大=%d / 临界=%d / 边界内=%d%s" % (
            stats["bound_total"], stats["bound_min"], stats["bound_max"],
            stats["bound_critical"], stats["bound_inside"], depth_warn))
    else:
        print("  边界用例 0 条（若无边界场景可忽略，否则提示补齐）")
    print("-- 异常子类（references/coverage.md 8.2）--")
    if stats["exc_total"] > 0:
        hit_subs = [k for k, v in stats["exc_subtypes_hit"].items() if v > 0]
        miss_subs = [k for k, v in stats["exc_subtypes_hit"].items() if v == 0]
        print("  异常用例 %d 条，覆盖子类 %d/8：%s" % (stats["exc_total"], len(hit_subs), "/".join(hit_subs)))
        if miss_subs:
            print("  未覆盖异常子类：%s（按需补齐）" % "/".join(miss_subs))
    else:
        print("  异常用例 0 条（若无异常场景可忽略）")

    # 规则追溯
    uncovered, total_cat = traces["rule"]
    print("-- 规则追溯（解析'规则建模'section，校验每类被用例覆盖）--")
    if total_cat == 0:
        print("  未找到'规则建模'section（或无粗体规则项），跳过规则追溯校验")
    else:
        print("  规则类别 %d 类，未覆盖 %d 类" % (total_cat, len(uncovered) if uncovered else 0))
        if uncovered:
            print("  ⚠ 疑似未覆盖规则类别（供复核，可能为 token 匹配遗漏）：%s" % "、".join(uncovered))
        else:
            print("  全部规则类别均有用例覆盖")

    # 风险追溯（第5阶段风险清单 → 用例）
    unc_risk, p0p1_total, risk_total = traces["risk"]
    print("-- 风险追溯（解析'风险清单'section，校验每 P0/P1 风险被用例覆盖）--")
    if risk_total == 0:
        print("  ⚠ 未找到'风险清单'section（强制沉淀，请补齐以启用闭环与跨会话记忆）")
    else:
        print("  风险 %d 条（其中 P0/P1 %d 条），未覆盖 %d 条" % (
            risk_total, p0p1_total, len(unc_risk) if unc_risk else 0))
        if unc_risk:
            print("  ⚠ 疑似未覆盖 P0/P1 风险（供复核）：%s" % "；".join(unc_risk))
        else:
            print("  全部 P0/P1 风险均有用例覆盖")

    # 测试点追溯（第7阶段测试点清单 → 用例）
    unc_tp, tp_total = traces["testpoint"]
    print("-- 测试点追溯（解析'测试点清单'section，校验每测试点被用例覆盖）--")
    if tp_total == 0:
        print("  ⚠ 未找到'测试点清单'section（强制沉淀，请补齐以启用闭环与跨会话记忆）")
    else:
        print("  测试点 %d 条，未覆盖 %d 条" % (tp_total, len(unc_tp) if unc_tp else 0))
        if unc_tp:
            print("  ⚠ 疑似未覆盖测试点（供复核）：%s" % "；".join(unc_tp))
        else:
            print("  全部测试点均有用例覆盖")

    # #6 反向接口追溯（变更影响清单 -> 用例引用，契约/规则/场景三类覆盖）
    unc_api, api_total, ctype_issues = traces["interface"]
    print("-- 反向接口追溯 #6（变更接口 -> 用例 契约/规则/场景 三类覆盖）--")
    if api_total == 0:
        print("  跳过（未找到'变更影响清单'section；契约驱动分支未启用或无变更接口）")
    else:
        print("  变更接口 %d 个，未覆盖（缺类） %d 个" % (api_total, len(unc_api)))
        if unc_api:
            print("  ⚠ 疑似未覆盖（供复核）：%s" % "；".join(unc_api))
        else:
            print("  全部变更接口三类(契约/规则/场景)覆盖齐全")
        if ctype_issues:
            print("  ⚠ 变更类型越界：%s" % "；".join(ctype_issues))

    # 风险来源分布 + 待台账角色确认（risk.md 三源共验）
    # risk_rows 是否存在以 risk_total 判定（traces.risk[2]），与重构前 main 用 risk_rows 真值判定一致
    risk_total = traces["risk"][2]
    print("-- 风险来源（risk.md 三源共验，第5列为'风险来源'）--")
    if risk_total == 0:
        print("  未找到风险清单，跳过风险来源校验")
    else:
        if src_dist:
            print("  来源分布: %s" % " / ".join("%s=%d" % (k, v) for k, v in src_dist.items()))
        else:
            print("  风险清单未标注'风险来源'列（建议补齐：需求推导/技术隐含@开发/业务领域@业务/缺陷反哺）")
        if src_pending:
            print("  ⚠ 待台账角色确认的 P0/P1 风险（%d 条，见 clarification.md 角色路由）：" % len(src_pending))
            for p in src_pending[:10]:
                print("    - %s" % p)
        else:
            print("  无需台账角色确认的风险（或 P0/P1 均为需求推导）")

    # #4 反向需求追溯（需求文档条目 → 用例引用）
    unc_req, req_total = traces["requirement"]
    print("-- 反向需求追溯 #4（需求条目 → 用例引用）--")
    if unc_req is None:
        # 显式强提示（不再静默跳过）：区分"未传 REQ"与"REQ 不可解析"
        if req_doc_lines is None:
            reason = "需求文档第2参数缺失（REQ_<需求标识>.md 未传入或文件不存在）"
            fix = "按 references/phase0_manifest.md 步骤零落盘 case-design-out/REQ_<需求标识>.md 后重跑 'python verify_cases.py <TC.md> case-design-out/REQ_<需求标识>.md'"
        else:
            reason = "需求文档无可解析章节（parse_requirement_items_from_lines 仅认 ## 二级及以上 Markdown 标题或 REQ-xxx/需求N 显式编号）"
            fix = "在 REQ_<需求标识>.md 中补 ## 二级标题分节（按需求条目切分，如 ## 订单创建 / ## 库存扣减），或补 REQ-xxx/需求N 编号后重跑"
        print("  ⚠ 需求条目级覆盖未校验（#4 静默跳过升级为显式强提示·闭合覆盖盲区）")
        print("    原因：%s" % reason)
        print("    影响：'需求文档每条条目是否均有用例覆盖'未机器校验，覆盖退化为依赖 LLM 自查+人工审核")
        print("    修复：%s" % fix)
    else:
        print("  需求条目 %d 条，未被用例引用 %d 条" % (req_total, len(unc_req)))
        if unc_req:
            print("  ⚠ 未覆盖需求条目（第10阶段补齐，见 dedup_coverage.md 反向需求追溯）：" )
            for u in unc_req[:15]:
                print("    - %s" % u)
            if len(unc_req) > 15:
                print("    ...（其余 %d 条略）" % (len(unc_req) - 15))
        else:
            print("  全部需求条目均有用例引用")

    print("-" * 48)
    overall = "通过" if not hard_violations else "不通过"
    print("硬性校验结论: %s" % overall)
    print("（软性校验与覆盖统计不改变退出码，供模型 selfcheck 决策）")
    print("=" * 48)
    # 机器可验证摘要块：供 run_phase.py sentinel 比对 / 交付摘要原样粘贴（防手填）。
    # run_phase.py 重算本块哈希与 sentinel 比对，弱模型无法凭空伪造与脚本输出一致的哈希。
    digest = build_digest_block(findings, basename, req_doc_lines)
    print("```json-gate-digest")
    print(json.dumps(digest, ensure_ascii=False))
    print("```")


def build_digest_block(findings, basename, req_doc_lines=None):
    """从 findings 提取交付摘要须填的 5 项机器数值 + exit 意向 + 短哈希，组成机器可验证块。
    与 print_findings 口径一致；不重复打印明细，只给"摘要行"级 5 数。
    run_phase.py 读取本块（stdout 末尾的 fenced json-gate-digest）做 sentinel 防伪造比对。"""
    soft = findings["soft"]
    traces = findings["traces"]
    src_dist, src_pending = findings["risk_source"]
    unc_req, req_total = traces["requirement"]
    behsrc_n, _behsrc_list, has_req = soft["behavior"]
    rulesrc_n, _rulesrc_list = soft["rule_source"]
    complete_n, _complete_list = soft["completeness"]
    schema_n, _schema_list = soft["schema"]

    # #4 反向需求追溯：与 print_findings 口径一致区分 None(跳过) vs 列表
    if unc_req is None:
        if req_doc_lines is None:
            req_trace = "未校验(REQ缺失/不可解析,待消除)"
        else:
            req_trace = "未校验(REQ无可解析章节,待消除)"
    else:
        req_trace = "需求条目 %d 条、未引用 %d 条/%s" % (
            req_total, len(unc_req), "全部覆盖" if not unc_req else "有缺口")

    # 风险来源待确认数 = P0/P1 待台账角色确认数
    pending_n = len(src_pending) if src_pending else 0

    digest = {
        "script": "verify_cases.py",
        "file": basename,
        "n": findings["n"],
        "exit": 0 if not findings["hard_violations"] else 1,
        "hard": "通过" if not findings["hard_violations"] else "不通过",
        "summary": {
            "检查13_断言完整性": complete_n,
            "检查9增强_存储schema交叉": ("跳过" if schema_n is None else schema_n),
            "风险来源待确认_P0P1": pending_n,
            "#4_反向需求追溯": req_trace,
            "#5_业务行为来源追溯": behsrc_n,
            "规则来源_破自证": rulesrc_n,
        },
    }
    # 短哈希：覆盖 file/n/exit/hard/summary（不含 script/hash 自身），防伪造者改 n/exit
    # 却照抄 hash 行。run_phase.py 重算比对。
    hash_payload = {
        "file": digest["file"],
        "n": digest["n"],
        "exit": digest["exit"],
        "hard": digest["hard"],
        "summary": digest["summary"],
    }
    digest["hash"] = hashlib.sha256(
        json.dumps(hash_payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
    ).hexdigest()[:8]
    return digest


def main():
    if len(sys.argv) >= 2 and sys.argv[1] in ("--dump-rules", "--rules"):
        dump_rules()
        return 0
    if len(sys.argv) < 2:
        print("用法: python verify_cases.py <TC文件.md> [需求文档.md]  |  --dump-rules 查看规则契约")
        print("  第2参数：需求文档 case-design-out/REQ_<需求标识>.md（第0阶段步骤零已强制落盘），用于 #4 反向需求追溯 + #5 token 核对；缺失则 #4 产出显式强提示而非静默跳过")
        return 1

    path = sys.argv[1]
    req_doc_path = sys.argv[2] if len(sys.argv) >= 3 else None
    parsed, err = parse_table(path)
    if parsed is None:
        print(err)
        return 1
    header_cells, data_rows, lines = parsed

    # 读需求文档行（供 #4/#5）；路径不存在/不可读则传 None（与重构前 check_behavior_source/
    # reverse_requirement_trace 的文件不存在兜底语义一致：#5 退回 (b)(c)、#4 跳过）
    req_doc_lines = None
    if req_doc_path and os.path.exists(req_doc_path):
        try:
            with open(req_doc_path, "r", encoding="utf-8") as f:
                req_doc_lines = f.readlines()
        except Exception:
            req_doc_lines = None

    findings = collect_all_findings(data_rows, lines, req_doc_lines=req_doc_lines)
    # 附 data_rows 供 print_findings 复算 id/field 分组（幂等，与原 main 调用次序一致）
    findings["_data_rows"] = data_rows
    print_findings(findings, os.path.basename(path), req_doc_lines=req_doc_lines)

    return 1 if findings["hard_violations"] else 0


if __name__ == "__main__":
    sys.exit(main())
