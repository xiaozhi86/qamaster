class ApprovalGate:
    def require(self, step):
        if step.get("human_approval",False):
            return "WAIT_USER_CONFIRM"
        return "APPROVED"
