"""Enterprise workflow runtime core."""
import yaml
from .state_machine import StateMachine

class WorkflowEngine:
    def __init__(self, workflow_file):
        self.workflow = yaml.safe_load(open(workflow_file,encoding="utf-8"))
        self.state = StateMachine(self.workflow)

    def run_step(self, agent_result):
        step=self.state.current()
        if not agent_result:
            raise RuntimeError("Step artifact missing")
        self.state.complete(step["id"])
        return self.state.next()
