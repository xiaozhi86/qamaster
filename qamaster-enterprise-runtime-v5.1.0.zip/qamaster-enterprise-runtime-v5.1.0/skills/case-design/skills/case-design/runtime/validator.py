class ArtifactValidator:
    def validate(self, artifact, required):
        missing=[x for x in required if x not in artifact]
        if missing:
            raise ValueError("Missing artifacts: "+str(missing))
        return True
