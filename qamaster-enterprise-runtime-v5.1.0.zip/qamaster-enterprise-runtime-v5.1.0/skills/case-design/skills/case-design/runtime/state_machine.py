class StateMachine:
    def __init__(self, workflow):
        self.steps=workflow.get("steps",[])
        self.index=0
    def current(self):
        return self.steps[self.index]
    def complete(self, step_id):
        if self.current()["id"] != step_id:
            raise RuntimeError("Invalid workflow transition")
    def next(self):
        self.index += 1
        return self.steps[self.index] if self.index < len(self.steps) else None
