# Agent Orchestrator

Runtime负责调度。

Agents:
- BA
- PM
- QA
- ARCH
- RISK
- REVIEWER

模型只负责推理和内容生成，不控制流程。
