# qamaster Enterprise Runtime v5.1.0

目标：将Skill流程控制从LLM迁移到Runtime。

Runtime负责：
- workflow
- state
- validation
- approval

Model负责：
- reasoning
- generation
