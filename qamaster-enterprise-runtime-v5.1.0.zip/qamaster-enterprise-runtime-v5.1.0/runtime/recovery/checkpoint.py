import json, pathlib, datetime
class CheckpointManager:
    def __init__(self, root='.runtime/checkpoints'):
        self.root=pathlib.Path(root); self.root.mkdir(parents=True,exist_ok=True)
    def save(self, step, data):
        data['timestamp']=datetime.datetime.utcnow().isoformat()
        (self.root/f'{step}.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
