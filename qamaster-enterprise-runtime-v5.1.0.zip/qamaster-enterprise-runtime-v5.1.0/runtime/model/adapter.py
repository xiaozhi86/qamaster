class ModelAdapter:
    def generate(self,prompt,context=None):
        raise NotImplementedError
