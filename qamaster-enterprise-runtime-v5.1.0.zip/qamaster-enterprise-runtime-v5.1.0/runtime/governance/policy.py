DEFAULT_POLICY={
 'forbid_skip_step':True,
 'forbid_auto_approve':True,
 'require_artifact':True,
 'require_validator':True
}
