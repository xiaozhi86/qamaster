import json, pathlib, datetime
class AuditLogger:
    def __init__(self, path='.runtime/audit.log'):
        self.path=pathlib.Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)
    def log(self,event,**kwargs):
        with self.path.open('a',encoding='utf8') as f:
            f.write(json.dumps({'event':event,'time':datetime.datetime.utcnow().isoformat(),**kwargs},ensure_ascii=False)+'\n')
