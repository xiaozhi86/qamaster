class RuntimeLifecycle:
    STATES = ["INSTALL","INITIALIZE","READY","RUNNING","WAIT_APPROVAL","COMPLETED","ARCHIVED"]
    def __init__(self):
        self.state = "INSTALL"
    def transition(self, state):
        if state not in self.STATES:
            raise ValueError(state)
        self.state = state
